import{bG as o}from"./vendor-04d54f89.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
//# sourceMappingURL=NoPage-18c23035.js.map
