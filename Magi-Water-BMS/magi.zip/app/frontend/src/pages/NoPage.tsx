export function Component(): JSX.Element {
    return <h1>404</h1>;
}

Component.displayName = "NoPage";
